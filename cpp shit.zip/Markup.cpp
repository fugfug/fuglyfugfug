#include <iostream>
#include <iomanip>
using namespace std;

double calculateRetail(double, double);
void printRetail(double);

int main()
{
	double cost;	//wholesale cost
	double percent;	//markup percentage
	double price;	//retail price

        cout << "Enter the item's wholesale cost: ";
        cin >> cost;
        cout << "Enter the item's markup percentage: ";
	cin >> percent;
	
	cout << fixed << showpoint << setprecision(2);

	//calls calculateretail function
	price =	calculateRetail(cost, percent);

	//calls printretail function
	printRetail(price);

	return 0;
}

double calculateRetail(double wholesaleCost, double percentage)       
{
        double price = (wholesaleCost * (percentage/100)) + wholesaleCost;
	return price;
}

void printRetail(double retailPrice)
{
	cout << "The item's price is: $" << retailPrice << "." << endl;
}
 
