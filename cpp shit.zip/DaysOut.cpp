#include <iostream>
#include <iomanip>
using namespace std;

int getEmployees();
int getDaysOut(int);
double calcAverage(int, int);

int main()
{
	int employees;
	int days;

	int number = getEmployees(); 	//number of employees
	int total = getDaysOut(number);	//total number of days out
	double avg = calcAverage(number, total);

	cout << "The average number of days missed was " << avg << "." << endl;
}

int getEmployees()
{
	int employees;
        cout << "How many employees are there in the company? ";
	cin >> employees;
	return employees;
}

int getDaysOut(int number)
{
	//number is number of employees
	int days;		//days missed
	int total;

        for (int i = 1; i <= number; i++)
	{
        	cout << "How many days did employee " << i << " miss? ";
		cin >> days;
		int total = 0;
	        total = total + days;
	}
	return total;
}

double calcAverage(int number, int total)
{
	cout << fixed << showpoint << setprecision(2);
	double average;
	average = total/number;
	return average;
}
