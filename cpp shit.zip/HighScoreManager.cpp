/*
 * Class: CS 110A
 * Description: The program manages a list of up to 10 players and their high scores in the computer's memory.
 * Due Date: May 18, 2016
 * Name: Kelly Suen
 * File Name: HighScoreManager.cpp
 * Assignment #7
 */

#include <iostream>
#include <string>
using namespace std;

const int SIZE = 10;
void addPlayer(string[], int[], int&, int);
void printPlayers(string[], int[], int&);
void searchPlayers(string[], int[], string, int);
void removePlayer(string[], int[], string, int);

int main()
{
        const int ADD = 1, PRINT = 2, SEARCH = 3, REMOVE = 4, QUIT = 5;
        int score[SIZE];
        string player[SIZE];
        string searchplayer;
	string removeplayer;
        int option;
	string playerprint[SIZE];
	int scoreprint[SIZE];
	int counter;
	int searchresults;
	
        cout << "Enter an option."
             << "\n1. Add new player and score."
             << "\n2. Print all players and scores."
             << "\n3. Search for a player's score."
             << "\n4. Remove a player."
             << "\n5. Quit." << endl;
        cin >> option;

        if(option == ADD)
                addPlayer(player, score, counter, SIZE);
	else if (option == PRINT)
		printPlayers(playerprint, scoreprint, counter);
	else if (option == SEARCH) 
		searchPlayers(player, score, searchplayer, SIZE);
	else if (option == REMOVE)
		removePlayer(player, score, removeplayer, SIZE);
	else
		return 0;
}



void addPlayer(string p[], int scores[], int& count, int size)
{
        cout << "Enter new player name." << endl;
        cin >> p[size];
        cout << "Enter new player score." << endl;
        cin >> scores[size];
	count++;
}

void printPlayers(string p[], int scores[], int& count)
{	
	cout << "Player " << "\t\t Scores" << endl;
	for(int i = 0; i < count; i++)
	{	
		cout << p[i] << " \t\t " << scores[i] << endl;
		
	}
}

void searchPlayers(string p[], int scores[], string sPlayers, int elements)
{
	cout << "What player to search for?" << endl;
	cin >> sPlayers;

	int index = 0;
	int position = -1; 
	bool found = false;

	while (index < elements && !found)
	{
		if (p[index] == sPlayers) 
		{
		found = true;
         	position = index;
      		}
      		index++;
   	}
	int searchresults = position;
	if (searchresults == -1)
      		cout << "Cannot find." << endl;
   	else
   	{
      		cout << "the score for " << sPlayers << " is ";
      		cout << (searchresults + 1) << endl;
   	}
}

void removePlayer(string p[], int scores[], string rPlayer, int elements)
{
	cout << "What player to remove?" << endl;
	cin >> rPlayer;
	
	for(int i = 0; i < elements; i++)
	{
	if(p[i] == rPlayer)
		p[i] = p[elements];
	}
}
