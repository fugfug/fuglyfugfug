/*
* Class: CS 110A
* Description: This program gives the user a choice to test either addition, subtraction, or multiplication by generating two random numbers to test with.
* Due Date: February 24, 2016
* Name: Kelly Suen
* File Name: MathTutor.cpp
* Lab #5
*/

#include <iostream>
#include <cstdlib>
using namespace std;

int main()
{
	int choice;
	srand(time(0));
	int num1 = rand() % 10; //generates a random number between 0 and 9
	int num2 = rand() % 10; //generates another random number between 0 and 9
	int temp; //temporary int for swapping
	int answer;
	const int ADDITION = 1; //choice 1
	const int SUBTRACTION = 2; //choice 2
	const int MULTIPLICATION = 3; //choice 3 

	//displays the main menu
	cout << "Main menu \n" <<
	"1: Addition \n" <<
	"2: Subtraction \n" <<
	"3: Multiplication \n" <<
	"4: Exit \n" << 
	"Enter a choice: " ;
	cin >> choice;

        switch(choice) //user choices and possible outcomes for each choice
	{
        	case ADDITION: 
			cout << "What is " << num1 << " + " << num2 << "? " ; 	//displays an addition question
			cin >> answer; 						//user inputs answer
				if (answer == num1 + num2)			//if user's answer is the same as the actual answer
					cout << "Correct\n" ;			//program tells the user the answer is correct
				else						//if user's answer is different from the actual answer, displays the correct answer
					cout << "Your answer is wrong. The correct answer is " << num1 + num2 << endl;
			break;
		case SUBTRACTION:
                        if (num1 < num2) 		//in case num1 is smaller and will result in a negative answer 
                        {       temp = num1; 		//swap to make num1 greater than num2 using a temporary int
                                num1 = num2;
                                num2 = temp; } 
			cout << "What is " << num1 << " - " << num2 << "? " ;	//displays a subtraction question
                        cin >> answer;
                        	if (answer == (num1 - num2))
                                	cout << "Correct\n" ;
                        	else
                                	cout << "Your answer is wrong. The correct answer is " << num1 - num2 << endl;
			break;
		case MULTIPLICATION:
                        cout << "What is " << num1 << " * " << num2 << "? " ;	//displays a multiplication question
                        cin >> answer ;
				if (answer == num1 * num2)
					cout << "Correct\n" ;
				else
					cout << "Your answer is wrong. The correct answer is " << num1 * num2 << endl;
			break; 
		default: 			// if user chooses this case, the program will end and displays the word exit 
			cout << "exit\n" ;
		
	}
	return 0;
}


//sample runs
/*

Main menu 
1: Addition 
2: Subtraction 
3: Multiplication 
4: Exit 
Enter a choice: 1
What is 1 + 6? 7
Correct

Main menu 
1: Addition 
2: Subtraction 
3: Multiplication 
4: Exit 
Enter a choice: 1
What is 2 + 8? 9
Your answer is wrong. The correct answer is 10

Main menu 
1: Addition 
2: Subtraction 
3: Multiplication 
4: Exit 
Enter a choice: 2
What is 2 - 0? 2
Correct

Main menu 
1: Addition 
2: Subtraction 
3: Multiplication 
4: Exit 
Enter a choice: 2
What is 7 - 7? 7
Your answer is wrong. The correct answer is 0

Main menu 
1: Addition 
2: Subtraction 
3: Multiplication 
4: Exit 
Enter a choice: 3
What is 0 * 2? 0
Correct

Main menu 
1: Addition 
2: Subtraction 
3: Multiplication 
4: Exit 
Enter a choice: 4
exit

*/
