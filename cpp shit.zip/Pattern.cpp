#include <iostream>
#include <string>
using namespace std;

int main ()
{
	string firstName, lastName, collegeMajor;
	firstName = "Kelly";
	lastName = "Suen";
	collegeMajor = "Art";	 

	cout << 
		"   *\n" << 
		"  ***\n" << 
		" *****\n" << 
		"*******\n" << 
		" *****\n" << 
		"  ***\n" << 
		"   *\n" << 
		firstName << " " << lastName << 
		" \n" << collegeMajor <<  endl;

}
