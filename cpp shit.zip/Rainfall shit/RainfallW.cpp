#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;

int main()
{
	ofstream outfile;

        int years, inches;
        double average;
        double tot_inches = 0;
        int tot_months = 0;

	outfile.open("rainfall.txt");


        cout << "This program will calculate average rainfall over a period of years."
             << "\nHow many years do you wish to average? ";
        cin >> years;
        cout << endl; //blank line

        int y;
	int m;
	for(y = 1; y <= years; y++) {
                cout << "Year " << y << endl;

           for (m = 1; m <= 12; m++) {
                cout << "Number of inches of rain for month # " << m << " ? ";
                cin >> inches;
                tot_inches += inches;
           }
	}

	cout << endl;
        tot_months = years * 12;
        average = tot_inches / tot_months;

        cout << "Over a period of " << tot_months << " months, " << tot_inches
             << " inches of rain fell." << endl;
        cout << fixed << showpoint << setprecision(3);
        cout << "Average monthly rainfall for the period is "
             << average << " inches" << endl;



        outfile << "Years: " << years << endl;
        outfile << "Total inches: " << tot_inches << endl;
        outfile << "Total months: " << tot_months << endl;
        outfile << "Average: " << average << endl;
        outfile.close();

}
