#include <iostream>
#include <string>
using namespace std;

int main()
{
	double count = 0;
	const int SIZE = 12;
	double rainfall[11];
	string months[SIZE] = { "January", "February", "March", "April", 
			"May", "June", "July", "August", "September",
			"October", "November", "December" }; 

	for(int i = 0; i < SIZE; i++)
	{
	cout << "Enter rainfall for " << months[i] << ": ";
	cin >> rainfall[i];
	while(rainfall[i] < 0)
	{
	cout << "invalid data (negative rainfall) -- retry: ";
	cin >> rainfall[i];
	}
	count = count + rainfall[i];
	}

        int lowest = rainfall[0];
        int highest = rainfall[0];
        string l = months[0];
        string h = months [0];

	//comparing arrays to find the lowest and highest
	for(int j = 1; j < SIZE; j++)
	{
        if(rainfall[j] < lowest) {
                lowest = rainfall[j];
		l = months[j];
		}
        if(rainfall[j] > highest) {
                highest = rainfall[j];
		h = months[j];
        	}
	}

        cout << "Total rainfall: " << count << endl;
        double avg = count / SIZE;
        cout << "Average rainfall: " << avg << endl;

	cout << "Least rainfall in: " << l << endl;	
	cout << "Highest rainfall in: " << h << endl;
}

/** sample run
Enter rainfall for January: -666
invalid data (negative rainfall) -- retry: 19
Enter rainfall for February: 10
Enter rainfall for March: 12
Enter rainfall for April: 13
Enter rainfall for May: 5
Enter rainfall for June: 4
Enter rainfall for July: 6
Enter rainfall for August: 3
Enter rainfall for September: 9
Enter rainfall for October: 10
Enter rainfall for November: 14
Enter rainfall for December: 15
Total rainfall: 120
Average rainfall: 10
Least rainfall in: August
Highest rainfall in: January

*/
