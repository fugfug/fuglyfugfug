#include<iostream>
#include<iomanip>
using namespace std;

int main()
{

	int years, inches;
	double average;
	double tot_inches = 0;
	int tot_months = 0;

	cout << "This program will calculate average rainfall over a period of years."
	     << "\nHow many years do you wish to average? ";
	cin >> years;
		
	cout << endl; //blank line
	
	int y;
	int m;
	for(y = 1; y <= years; y++) {
		cout << "Year " << y << endl; 

	   for (m = 1; m <= 12; m++) {
		cout << "Number of inches of rain for month # " << m << " ? ";
		cin >> inches;
		tot_inches += inches;
		
	   }

	}

	cout << endl;
	tot_months = years * 12;
	average = tot_inches / tot_months;
	
	cout << "Over a period of " << tot_months << " months, " << tot_inches 
	     << " inches of rain fell." << endl;
        cout << fixed << showpoint << setprecision(3);
	cout << "Average monthly rainfall for the period is "
	     << average << " inches" << endl;

	return 0;

}
