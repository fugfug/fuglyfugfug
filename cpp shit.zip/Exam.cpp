#include <iostream>

using namespace std;

int main()
{
	const int SIZE = 20;
	char correctAnswers[SIZE] = { 'A', 'D', 'B', 'B', 'C', 'B', 'A', 'B', 'C', 'D',
			       'A', 'C', 'D', 'B', 'D', 'C', 'C', 'A', 'D', 'B' }; 
	char userAnswers[SIZE];
	int wrong = 0;
	int correct = 0;
	int questionsWrong[SIZE] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0};

	cout << "Please enter the student's answers for each of the questions." << endl;
	cout << "Press Enter after typing each answer." << endl;
	cout << "Please enter only an A, B, C, or D for each question." << endl;

	int i;	
	for(i = 0; i < SIZE; i++) 
	{
		cout << "Question " << (i+1) << ": ";
		cin >> userAnswers[i];
		    if(userAnswers[i] != correctAnswers[i])
		    {
			wrong = wrong + 1;	//counter for number of correct answers
			questionsWrong[i] = i + 1;
		    }
		    else
			correct = correct + 1;	//counter for number of wrong answers
	}

	if(correct >= 15)			//minimum pass grade
	    cout << "\nThe student passed the exam." << endl;
	else
	    cout << "\nThe student failed the exam." << endl;
	cout << "\nCorrect Answers: " << correct << endl;
	cout << "Incorrect Answers: " << wrong << endl;
	cout << "\nQuestions that were answered incorrectly:" << endl;
	
	for(i = 0; i < SIZE; i++){
	   if(questionsWrong[i] > 0)
		cout << questionsWrong[i] << endl;
	}

	return 0;
}

/* sample run

Please enter the student's answers for each of the questions.
Press Enter after typing each answer.
Please enter only an A, B, C, or D for each question.
Question 1: A
Question 2: A
Question 3: A
Question 4: A
Question 5: A
Question 6: A
Question 7: A
Question 8: A
Question 9: C
Question 10: C
Question 11: C
Question 12: C
Question 13: C
Question 14: C
Question 15: D
Question 16: D
Question 17: D
Question 18: D
Question 19: A
Question 20: A

The student failed the exam.

Correct Answers: 5
Incorrect Answers: 15

Questions that were answered incorrectly:
2
3
4
5
6
8
10
11
13
14
16
17
18
19
20

*/
