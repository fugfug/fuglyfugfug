/*
 * Class: CS 110A
 * Description: 
 * Due Date: April 27, 2016
 * Name: Kelly Suen
 * File Name: Hospital.cpp
 * Assignment #5
 */

#include <iostream>
#include <iomanip>
using namespace std;

double patient(int, double, double, double);
double patient(double, double);

int main()
{
	char patientType;
	double rate, medCharges, serviceCharges, total;
	int days;

	cout << fixed << showpoint << setprecision(2);	
	cout << "This program will compute patient hospital charges." << endl;
	cout << "What was the patient type?" << endl;
	cout << "In-patient or Out-patient? (I or O) ";
	cin >> patientType;	

	if (patientType == 'I' || patientType == 'i') 
	{
	    total = patient(days, rate, medCharges, serviceCharges);
	    cout << endl;
	    cout << "The total charges are $" << total << endl;
	}

	else if (patientType == 'O' || patientType == 'o')
	{
	    total = patient(medCharges, serviceCharges);
	    cout << endl;
	    cout << "The total charges are $" << total << endl;
	}

	else
	return 0;
}


//***************************************************************
//   Definition of overloaded function patient.			*
//   This function uses an int parameter, d (for days), 	*
//   and three double parameters: rt, mCharges, and sCharges.	*
//   It returns the total as a double.				*
//***************************************************************

double patient(int d, double rt, double mCharges, double sCharges)
{
	cout << "Number of days in the hospital: ";
	cin >> d;
	while(d < 0)  
        {
        cout << "Days must be zero or more. Please re-enter: ";
        cin >> d;  
        }

	cout << "Daily room rate: $" ;
	cin >> rt;
        while(rt < 0)
        {
        cout << "Daily room rate must be zero or more. Please re-enter: ";
        cin >> rt;
        }

	cout << "Medication charges: $";
	cin >> mCharges;
        while(mCharges < 0)
        {
        cout << "Medication charges must be zero or more. Please re-enter: ";
        cin >> mCharges;
        }

	cout << "Lab fees and other service charges: $";
	cin >> sCharges;
        while(sCharges < 0)
        {
        cout << "Lab fees and other service charges must be zero or more. Please re-enter: ";
        cin >> sCharges;
        }

	double tot = (d * rt) + mCharges + sCharges;
	return tot;
}


//**************************************************************************
//   Definition of overloaded function patient.				   * 
//   This function uses two double parameters: rt, mCharges, and sCharges. *
//   It returns the total as a double.            			   *
//**************************************************************************

double patient(double mCharges, double sCharges) 
{
	cout << "Medication charges: $";
	cin >> mCharges;
	while(mCharges < 0) 
	{
	cout << "Medication charges must be zero or more. Please re-enter: ";
	cin >> mCharges; 
	}

	cout << "Lab fees and other service charges: $";
	cin >> sCharges;
	while(sCharges < 0)  
        {
        cout << "Lab fees and service charges must be zero or more. Please re-enter: ";
        cin >> sCharges;  
        }

	double tot = sCharges + mCharges;
	return tot;
}

/*****************************************************************
sample runs

This program will compute patient hospital charges.
What was the patient type?
In-patient or Out-patient? (I or O) i
Number of days in the hospital: 4
Daily room rate: $200
Medication charges: $300
Lab fees and other service charges: $50

The total charges are $1150.00

This program will compute patient hospital charges.
What was the patient type?
In-patient or Out-patient? (I or O) o
Medication charges: $-54
Medication charges must be zero or more. Please re-enter: 54
Lab fees and other service charges: $300

The total charges are $354.00

This program will compute patient hospital charges.
What was the patient type?
In-patient or Out-patient? (I or O) i
Number of days in the hospital: -9
Days must be zero or more. Please re-enter: 20
Daily room rate: $12.94
Medication charges: $65.83
Lab fees and other service charges: $111

The total charges are $435.63
***************************************************************/
