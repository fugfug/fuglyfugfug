#include <iostream>
using namespace std;

int main ()
{
	cout << " Hello World! " << endl;
	cout << " This is my very first program. " << endl;
	cout << " Kelly! " << endl;
	cout << " Programmed by Kelly Suen " << endl;

}
