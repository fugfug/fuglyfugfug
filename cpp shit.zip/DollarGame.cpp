/*
* Class: CS 110A
* Description: This program asks the user to enter the amount of coins required to make one dollar.
* Due Date: February 26, 2016
* Name: Kelly Suen
* File Name: DollarGame.cpp
* Extra Credit
*/

#include <iostream>

using namespace std;

int main()
{
	int pennies;	//amount of pennies user enters
	int nickels;	//amount of nickels user enters
	int dimes;	//amount of dimes user enters
	int quarters;	//amount of quarters user enters
	double total;			//total amount of change
	double const PENNY = .01;	//value of a penny
	double const NICKEL = .05;	//value of a nickel
	double const DIME = .1;		//value of a dime
	double const QUARTER = .25;	//value of a quarter
	double const DOLLAR = 1;	//value of a dollar

	cout << "Let's play a change-counting game." << endl;
	cout << "Enter the number of coins needed to make exactly one dollar." << endl;
	cout << "Enter the number of pennies: " ;
	cin >> pennies;		
	cout << "Enter the number of nickels: " ;
	cin >> nickels;
        cout << "Enter the number of dimes: " ;
        cin >> dimes;
        cout << "Enter the number of quarters: " ;
        cin >> quarters;

	//calculates total amount of change
	total = (pennies * PENNY) + (nickels * NICKEL) + (dimes * DIME) + (quarters * QUARTER);	
	if (total == DOLLAR)
		cout << "\nCongratulations! You win!" << endl; 	//gets displayed if total amount of change adds up to a dollar
	else if (total > DOLLAR)
		cout << "\nSorry, that's more than one dollar" << endl;	//gets displayed if total amount of change adds up to more than a dollar
	else
		cout << "\nSorry, that's less than one dollar" << endl;	// gets displayed if total amount of change adds up to less than a dollar
return 0;
}



/* 
sample runs

Let's play a change-counting game.
Enter the number of coins needed to make exactly one dollar.
Enter the number of pennies: 7
Enter the number of nickels: 5
Enter the number of dimes: 9
Enter the number of quarters: 12

Sorry, that's more than one dollar

Let's play a change-counting game.
Enter the number of coins needed to make exactly one dollar.
Enter the number of pennies: 1
Enter the number of nickels: 2
Enter the number of dimes: 3
Enter the number of quarters: 4

Sorry, that's more than one dollar

Let's play a change-counting game.
Enter the number of coins needed to make exactly one dollar.
Enter the number of pennies: 2
Enter the number of nickels: 8
Enter the number of dimes: 1
Enter the number of quarters: 1

Sorry, that's less than one dollar

Let's play a change-counting game.
Enter the number of coins needed to make exactly one dollar.
Enter the number of pennies: 0
Enter the number of nickels: 0
Enter the number of dimes: 0
Enter the number of quarters: 4

Congratulations! You win!

*/
