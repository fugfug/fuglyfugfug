/*
* Class: CS 110A
* Description: This program asks the user for their beginning balance and number of checks written and then calculates and displays the bank's service fees for the month.
* Due Date: February 26, 2016
* Name: Kelly Suen
* File Name: BankCharges.cpp
* Assignment #2
*/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int checks;			//number of checks written	
	int beginning_balance;		//beginning balance 
	double bankFees;		//total amount of bank fees		
	double const CHARGE1 = .10;	//amount charged for writing less than 20 checks, per check
	double const CHARGE2 = .08;	//amount charged for writing 20-39 checks, per check
	double const CHARGE3 = .06;	//amount charged for writing 40-59 checks, per check
	double const CHARGE4 = .04;	//amount charged for 60 or more checks, per check
	int monthly_fee = 10;		//amount bank charges per month
	int extra_fee = 15;		//amount bank charges if the balance of an account falls below $400

	cout << "Enter the following information about your checking account. " << endl;
	cout << "Beginning balance: $";
	cin >> beginning_balance;
                if (beginning_balance < 0) {
                        cout << "OVERDRAWN\n" ; }	//if beginning balance is negative, displays message stating account is overdrawn

	cout << "Number of checks written: " ;
	cin >> checks;	

	        if (beginning_balance < 400) {		//if beginning balance is below $400
	                if (checks < 0)  {                       //if checks written is negative
        	                cout << "negative values unacceptable" << endl;
				bankFees = monthly_fee + extra_fee; }		//bank's monthly fee and extra charge
                        else if (checks < 20)			//if checks written is less than 20, use CHARGE1 and extra fee to calculate bank fee 
                                bankFees = (CHARGE1 * checks) + monthly_fee + extra_fee;
                        else if (checks <= 39)			//if checks written is 20-39, use CHARGE2 and extra fee to calculate bankfee
                                bankFees = (CHARGE2 * checks) + monthly_fee + extra_fee;
                        else if (checks <= 59)
                                bankFees = (CHARGE3 * checks) + monthly_fee + extra_fee;
                        else					//if check written is 60 or more, use CHARGE4 and extra fee to calculate bank fee
                                bankFees = (CHARGE4 * checks) + monthly_fee + extra_fee; }

                else {						//if beginning balance is $400 or above
                        if (checks < 0)                         //if checks written is negative
                        {        cout << "negative values unacceptable" << endl;
                                bankFees = monthly_fee ;	}		//bank's monthly fee
                        else if (checks < 20)			//if checks written is less than 20, use CHARGE1
                                bankFees = (CHARGE1 * checks) + monthly_fee;	
                        else if (checks <= 39)
                                bankFees = (CHARGE2 * checks) + monthly_fee;
                        else if (checks <= 59)
                                bankFees = (CHARGE3 * checks) + monthly_fee;
                        else					//if checks written is 60 or more, use CHARGE4 to calculate bank fee
                                bankFees = (CHARGE4 * checks) + monthly_fee; }

        cout << fixed << showpoint << setprecision(2);		//displays up to 2 decimal points
        cout << "\nThe bank fee this month is $" << bankFees << endl; 		//displays bank fee for the month

	cout << "Programmed by Kelly Suen" << endl;

return 0;

}


/* sample runs

Enter the following information about your checking account. 
Beginning balance: $555
Number of checks written: 4

The bank fee this month is $10.40
Programmed by Kelly Suen

Enter the following information about your checking account. 
Beginning balance: $399
Number of checks written: 36

The bank fee this month is $27.88
Programmed by Kelly Suen

Enter the following information about your checking account. 
Beginning balance: $9999
Number of checks written: 70

The bank fee this month is $12.80
Programmed by Kelly Suen
 
*/
