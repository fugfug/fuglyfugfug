package Polynomial;

public class polynomial implements PolynomialADT{

	private int polynomial[];
	private final int MAX_SIZE = 20;

	public polynomial() {
		polynomial = new int[MAX_SIZE];
	}

	// returns the degree of the polynomial
	public int degree() {
		for (int i = MAX_SIZE - 1; i >= 0; i--) {
			// searches for the last non-zero coefficient (element) of
			// polynomial by starting from the end.
			// The power of the last non-zero coefficient is the degree.
			if (polynomial[i] != 0) 	// polynomial[i] is a coefficient
				return i; 				// returns the power of the coefficient
		}
		return 0; // default
	}

	// returns the coefficient of the x^power term
	// power must be in range: 0 to MAX_SIZE
	public int getCoefficient(int power) throws InvalidPowerException {		
		if (power < 0 || power > MAX_SIZE) // power is not in range, throw exception
			throw new InvalidPowerException("InvalidPowerException at getCoefficient");
		return polynomial[power]; // otherwise return coefficient of power
	}

	// Replaces the coefficient of the x^power term with newCoef
	// changeCoefficient also creates polynomial
	// newCoef replaces the old coefficient
	// power has to be greater than 0
	public void changeCoefficient(int newCoef, int power) throws InvalidPowerException {
		try {
			polynomial[power] = newCoef;
		} 
		catch (RuntimeException e) {
			if (power < -1 || power > MAX_SIZE) { // power out of range
												// power < -1 to allow entering '-1 -1'
				System.out.println("Error: cannot have negative power.");
				System.out.println("Please re-enter term and continue.");
			}
		}
	}

	// Takes the polynomial whose toString method is being called and
	// represents the polynomial as a string
	@Override
	public String toString() {
		String s = "";
		for (int i = MAX_SIZE - 1; i >= 0; i--) {
			if (polynomial[i] == 1 && i != 0 && i != 1) // 1x^4 -> x^4
				s += " + x^" + i; 

			else if (polynomial[i] == -1 && i != 0) //-1x^4 -> -x^4
				s += " - x^" + i;

			else if (i == 1 && polynomial[i] < 0) 
				s += " " + polynomial[i] + "x"; 

			else if (i == 1 && polynomial[i] > 0) //3x^1 -> 3x
				s += " + " + polynomial[i] + "x";

			else if (i == 0 && polynomial[i] < 0) // ex. -2x^0 -> -2
				s += " " + polynomial[i]; 

			else if (i == 0 && polynomial[i] > 0) // ex. 4x^0 -> 4
				s += " + " + polynomial[i];

			else if (polynomial[i] < 0 && i > 1) // coeffficient is neg
				s += " " + polynomial[i] + "x^" + i;

			else if (i == degree() && polynomial[i] > 0) // first term is pos
				s += polynomial[i] + "x^" + i;

			else if (polynomial[i] == 0) // 0^4 ->  
				s += "";

			else if (polynomial[i] == 1 && i == 1)
				s += "+ x";

			else
				s += (" + " + polynomial[i] + "x^" + i);

		}
		return s;

	}
	
	// Returns the sum of the given polynomial object and the polynomial argument
	public polynomial add(polynomial addend) { 
		for (int i = 0; i < MAX_SIZE; i++) {
			if (getCoefficient(i) != 0 && addend.getCoefficient(i) != 0) {
				// if polynomial's coefficient and addend's coefficient are not zero
				// add the coefficients 
				addend.changeCoefficient((getCoefficient(i) + addend.getCoefficient(i)), i);
			}
			else if (getCoefficient(i) != 0 && addend.getCoefficient(i) == 0) {
				// if addend's coefficient is 0, and polynomial's coefficient is not 0
				// "copy" the coefficient into addend at i 
				addend.changeCoefficient(getCoefficient(i), i);
			}
		}
		return addend;
	}

}
