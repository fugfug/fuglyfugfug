package Polynomial;


public class InvalidPowerException extends RuntimeException {

	public InvalidPowerException(String s) {

		super(s);

	}

}
