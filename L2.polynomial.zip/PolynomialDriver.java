package Polynomial;

import java.util.Scanner;

public class PolynomialDriver {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		polynomial p = new polynomial();
		polynomial p2 = new polynomial();

		
		int coefficient;
		int power;
		
		/*First Polynomial*/
		System.out.println(
				"Enter first polynomial." + "\nEnter each term on a separate line; coefficient followed by power."
						+ "\nFor example, 3 4 represents the term 3x^4."+"\nEnter -1 -1 to end input for the polynomial.");
		do{
			coefficient = scan.nextInt();
			power = scan.nextInt();
			p.changeCoefficient(coefficient, power); // changeCoefficient also adds/creates polynomials
		} while(coefficient != -1 || power !=-1); 
		System.out.println("First polynomial: " + p.toString());

		System.out.println();
		
		
		/*Second Polynomial*/
		System.out.println(
				"Enter second polynomial." + "\nEnter each term on a separate line; coefficient followed by power."
						+ "\nFor example, 3 4 represents the term 3x^4."+"\nEnter -1 -1 to end input for the polynomial.");
		do{
			coefficient = scan.nextInt();
			power = scan.nextInt();
			p2.changeCoefficient(coefficient, power);
		} while(coefficient != -1 || power != -1);
		System.out.println("Second polynomial: " + p2.toString());
		
		System.out.println();
		
		System.out.println("First polynomial: " + p.toString());
		System.out.println("Second polynomial: " + p2.toString());
		System.out.print("Sum: " + p.add(p2));
		
	}

	
	
}
