package Polynomial;

public interface PolynomialADT {

	public int degree(); // returns the degree of the polynomial
	public int getCoefficient(int power) throws InvalidPowerException;
						// returns the coefficient of the x^power term
	public void changeCoefficient(int newCoef, int power) throws InvalidPowerException;
					// Replaces the coefficient of the x^power term with newCoef
	public String toString();
		// Takes the polynomial whose toString method is being called and
		// represents the polynomial as a string
	public polynomial add(polynomial addend);
			// Returns the sum of the given polynomial object and the polynomial argument
}
