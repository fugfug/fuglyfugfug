public interface QueueInterface {

	public boolean isEmpty();
	// Determines whether a queue is empty.
	// Precondition: None.
	// Postcondition: Returns true if the queue is empty;
	// otherwise returns false.

	public void enqueue(Object newItem) throws QueueException;
	// Adds an item at the back of a queue
	
	public Object dequeue() throws QueueException;
	// Retrieves and removes the front of a queue

	public void dequeueAll();
	// Removes all items of a queue

	public Object peek() throws QueueException;
	// Retrieves the item at the front of a queue

	public String oddListings();
	// returns a string that contains the Queue's Node contents in the 1st, 3rd,
	// 5th, 7th, etc positions in the Queue for all odd numbered positions in
	// the Queue

	public String evenListings();
	// returns a string that contains the Queue's Node contents in the 2nd, 4th,
	// 6th, 8th, etc positions in the Queue for all even numbered positions in
	// the Queue
}