import java.util.Scanner;

public class L4Driver {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		QueueReferenceBased q = new QueueReferenceBased();
		menu();
		int choice = scan.nextInt();

		while (choice == 1 || choice == 2 || choice == 3||choice == 4){
			if (choice == 1) { // add item
				System.out.print("Enter item: ");
				Object item = scan.next(); 
				q.enqueue(item);
				System.out.println();
				menu();
				choice = scan.nextInt();
			} else if (choice == 2) { // show odds
				System.out.println("Queue items in odd positions: "
							+ q.oddListings());
				System.out.println();
				menu();
				choice = scan.nextInt();
			} else if (choice == 3) { // show evens
				System.out.println("Queue items in even positions: "
								+ q.evenListings());
				System.out.println();
				menu();
				choice = scan.nextInt();
			} else if (choice == 4){ 
				// anything but 1, 2, 3, or 4 ends program w/o a "goodbye"
				System.out.println("Goodbye");
				break;
			}
		}

	}

	public static void menu() {
		System.out.println("1) Add item" + "\n2) Show Queue items in odd positions"
				+ "\n3) Show Queue items in even positions" + "\n4) Exit program");
		System.out.print("Enter your choice(1-3): ");
	}
}
