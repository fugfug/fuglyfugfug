public class QueueReferenceBased implements QueueInterface {

	private Node lastNode;
	
	String odds = " "; // to save/hold odd position contents
	String evens = " ";// to save even position contents

	public QueueReferenceBased() {
		lastNode = null;
	} // end default constructor

	// queue operations:
	public boolean isEmpty() {
		return lastNode == null;
	} // end isEmpty

	public void dequeueAll() {
		lastNode = null;
	} // end dequeueAll

	public void enqueue(Object newItem) {
		Node newNode = new Node(newItem);

		// insert the new node
		if (isEmpty()) {
			// insertion into empty queue
			newNode.next = newNode;
		} else {
			// insertion into nonempty queue
			newNode.next = lastNode.next;
			lastNode.next = newNode;
		} // end if

		lastNode = newNode; // new node is at back
	} // end enqueue

	public Object dequeue() throws QueueException {
		if (!isEmpty()) {
			// queue is not empty; remove front
			Node firstNode = lastNode.next;
			if (firstNode == lastNode) { // special case?

				lastNode = null; // yes, one node in queue
			} else {
				lastNode.next = firstNode.next;
			} // end if
			return firstNode.item;
		} else {
			throw new QueueException("QueueException on dequeue:" + "queue empty");
		} // end if
	} // end dequeue

	public Object peek() throws QueueException {
		if (!isEmpty()) {
			// queue is not empty; retrieve front
			Node firstNode = lastNode.next;
			return firstNode.item;
		} else {
			throw new QueueException("QueueException on peek:" + "queue empty");
		} // end if
	} // end peek
	

	
	// precondition: none
	// postcondition: returns a string
	public String oddListings() {
		// returns a string that contains the Queue's Node contents in the 1st, 3rd,
		// 5th, 7th, etc positions in the Queue for all odd numbered positions in
		// the Queue

		while(!isEmpty()) { // keep dequeueing until queue is empty
			odds += dequeue() + " ";  // add the item into the "odds" string
			if (isEmpty())  // when the list is empty, 
				return odds; // stop adding 
			evens += dequeue() + " "; // keep even position items in another string
		}
		return odds;
	}

	// precondition: none
	// postcondition: returns a string
	public String evenListings() {
		// returns a string that contains the Queue's Node contents in the 2nd, 4th,
		// 6th, 8th, etc positions in the Queue for all even numbered positions in
		// the Queue

		while(!isEmpty()) {// keep dequeueing until queue is empty
			odds += dequeue() + " "; // keep odd position items in another string
			if (isEmpty()) { // when the list is empty, 
				return evens;// stop adding. 
			}
			evens += dequeue() + " ";  // add the item into the "evens" string
		}
		return evens;
	}
	
} // end QueueReferenceBased
