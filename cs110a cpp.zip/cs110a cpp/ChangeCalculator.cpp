/*
 * Class: CS 110A
 * Description: This program allows the user to input a number of quarters, nickels, and dimes, and outputs the amount of coins in cents.
 * Due Date: February 10, 2016
 * Name: Kelly Suen
 * File Name: ChangeCalculator.cpp
 * Assignment #1
 *
 */

#include <iostream>
using namespace std;

int main ()
{
	int quarters, dimes, nickels, cents;

	cout << " Enter number of quarters: ";
	cin >> quarters;
	
	cout << " Enter number of dimes: ";
	cin >> dimes;
	
	cout << " Enter number of nickels: ";
	cin >> nickels;

	//calculates monetary value of the coins
	cents = ( quarters * 25 ) + ( dimes * 10 ) + ( nickels * 5 );
	cout << " The monetary value of your coins is " << cents << " cents. \n " << endl ;
	
	cout << " Programmed by Kelly Suen \n " ;
	return 0;
}
