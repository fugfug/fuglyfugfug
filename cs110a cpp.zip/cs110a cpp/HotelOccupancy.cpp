/*
 * Class: CS 110A
 * Description: This program calculate the occupancy rate for a hotel.
 * Due Date: March 23, 2016
 * Name: Kelly Suen
 * File Name: HotelOccupancy.cpp
 * Assignment #3
 *
 */

#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	int floors, rooms, occupied;
	double tot_rooms = 0;
	double tot_occupied = 0;
	int vacant;
	double rate;

	cout << "How many floors does the hotel have? ";
	cin >> floors;
	   while (floors < 1) {
		cout << "Invalid. Enter 1 or more: ";
		cin >> floors;	
	   }

	int f;
	int r; 
	for (f = 1; f <= floors; f++) 	{ 
		cout << endl;
		if (f == 13)
		   continue;  
                cout << "How many rooms does floor " << f << " have? ";
		cin >> rooms;

	   while (rooms < 10) {
		cout << "Invalid. Enter 10 or more: ";
	   	cin >> rooms; 
	   }
		cout << "How many occupied rooms does floor " << f << " have? ";
		cin >> occupied; 

		tot_rooms += rooms;
		tot_occupied += occupied;
                rate = (tot_occupied / tot_rooms) * 100;
		vacant = tot_rooms - tot_occupied;
	} 
	cout << fixed << showpoint << setprecision(1);
	cout << "\nNumber of rooms: " << tot_rooms << endl;
	cout << "Occupied rooms: " << tot_occupied << endl;
	cout << "Vacant rooms: " << vacant << endl;
	cout << "Occupancy rate: " << rate << "%" << endl;

	return 0;
}

/* sample runs
How many floors does the hotel have? 5

How many rooms does floor 1 have? 0
Invalid. Enter 10 or more: 15
How many occupied rooms does floor 1 have? 10

How many rooms does floor 2 have? 12
How many occupied rooms does floor 2 have? 8

How many rooms does floor 3 have? 15
How many occupied rooms does floor 3 have? 15

How many rooms does floor 4 have? 12
How many occupied rooms does floor 4 have? 6

How many rooms does floor 5 have? 15
How many occupied rooms does floor 5 have? 12

Number of rooms: 69.0
Occupied rooms: 51.0
Vacant rooms: 18
Occupancy rate: 73.9%

*/
