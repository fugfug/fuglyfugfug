#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main ()
{
	string name;
	string email;
	double firstGrade, secondGrade, thirdGrade, avgGrade;	
	
	cout << "Please input the student name: " ;
	getline(cin, name);

	cout << "Enter your email address: " ;
	getline(cin, email);

	cout << "\nPlease input the first grade: " ;
	cin >> firstGrade;

	cout << "Please input the second grade: " ;
	cin >> secondGrade;

	cout << "Please input the third grade: " ;
	cin >> thirdGrade;

	avgGrade = (firstGrade + secondGrade + thirdGrade) / 3 ;
	cout << setprecision(2) << fixed << showpoint ;
	cout << "\nStudent name: " << name << endl ;
	cout << "Student email address: " << email << endl ;
	cout << "The average of the three grades is: " << avgGrade << endl ;
	return 0;
}

// sample run
/*
 */
