#include <iostream>
#include <cstdlib> 	//for use of rand
#include <ctime>	//for time
using namespace std;
int main ()
{
	int number;			//the number the user guesses
	int counter = 1;		//initialize counter
	unsigned seed = time(0);	
	srand(seed);
	int randnum = rand() % 10;	//generates random number up to 10

        cout << "I'm thinking of a number. Can you guess what it is? ";
        cin >> number;
  
        do {        
        if (number > randnum) { 
	       cout << "Sorry, that's too high. \n"    
                    << "Guess again: " ;               
                cin >> number;                          
                counter++ ;                             
        } 
	else if (number < randnum)
        {	//if the guessed number is lower than the generated number,
                cout << "No, that's too low. \n"
                     << "Guess again: ";                //a message is displayed
                cin >> number;                          //enter guess again
                counter++ ;
        }               		
	} while (number != randnum);
	
              	cout << "Congratulations! You guessed it!" << endl;
                cout << "I was thinking of the number " << randnum  << endl;
                cout << "\nThe number of guesses is " << counter << endl;

	return 0;
}

