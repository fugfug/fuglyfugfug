/*
 * Class: CS 110A
 * Description: Program allows user to play rock, paper, scissors against the computer.
 * Due Date: April 15, 2016
 * Name: Kelly Suen
 * File Name: RPSGame.cpp
 * Assignment #4
 */

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int getComputerChoice();
int getUserChoice();
void displayChoice(int);
void determineWinner(int, int);

int main()
{
	int randnum;
	int choice; //user choice
	int compChoice;
	const int ROCK = 1,
		  PAPER = 2,
		  SCISSORS = 3,
		  QUIT = 4;

        cout << "Let's play Rock, Paper, Scissors!" << endl;
        cout << "Game Menu\n" <<
                "------------\n" <<
                "1) Rock\n" <<
                "2) Paper\n" <<
                "3) Scissors\n" <<
                "4) Quit" << endl;
	int COMChoice = getComputerChoice();	//calls the function getComputerChoice
	int USERChoice = getUserChoice();	//calls the function UserChoice
	displayChoice(COMChoice);		//calls displayChoice
	determineWinner (USERChoice, COMChoice);	
	return 0;
}

int getComputerChoice()
{	
	//generates random number
	unsigned seed = time(0);
	srand(seed);
	int randnum = rand() % 3 + 1;
	return randnum;
}

int getUserChoice()
{
	//user is asked for and enters their choice
	int choice;
	cout << "Enter your choice: ";
	cin >> choice;
   if(choice != 4)  {
      while(choice < 1 || choice > 4)   {
	cout << "Invalid selection. Enter 1, 2, 3, or 4: ";
        cin >> choice;
      }
   }
	return choice;
}

void displayChoice(int x)
{
	int y;  //user choice
		//int x is the computer's choice

        if (y == 1)
           cout << "You selected: Rock " << endl;         
        else if (y == 2 )
           cout << "You selected: Paper " << endl;         
        else    //userChoice == 3
           cout << "You selected: Scissors " << endl;

    /*********************************************************/

        if (x == 1)
           cout << "The computer selected: Rock " << endl;
        else if (x == 2)
           cout << "The computer selected: Paper " << endl;
        else    //compChoice == 3
           cout << "The computer selected: Scissors " << endl;
  
}

void determineWinner(int uChoice, int cChoice)
{
	if (uChoice == 1 && cChoice == 2)
		cout << "Computer win! Paper covers rock." << endl;
	else if (uChoice == 1 && cChoice == 3)
		cout << "You win! Rock smashes scissors. " << endl;
	else if (uChoice == 2 && cChoice == 1)
		cout << "You win! Paper covers rock. " << endl;
	else if (uChoice == 2 && cChoice == 3)
		cout << "Computer wins! Scissors cuts paper. " << endl;
	else if (uChoice == 3 && cChoice == 1)
		cout << "Computer wins! Rock smashes scissors. " << endl;
	else if (uChoice == 3 && cChoice == 2)
		cout << "You win! Scissors cuts paper. " << endl;
	else if (uChoice == cChoice)
		cout << "Tie. No winner. " << endl;
}


/**********************************************************************
sample runs

Let's play Rock, Paper, Scissors!
Game Menu
------------
1) Rock
2) Paper
3) Scissors
4) Quit
Enter your choice: 1
You selected: Rock 
The computer selected: Paper 
Computer win! Paper covers rock.

Let's play Rock, Paper, Scissors!
Game Menu
------------
1) Rock
2) Paper
3) Scissors
4) Quit
Enter your choice: 3
You selected: Scissors 
The computer selected: Paper 
You win! Scissors cuts paper. 

Let's play Rock, Paper, Scissors!
Game Menu
------------
1) Rock
2) Paper
3) Scissors
4) Quit
Enter your choice: -8
Invalid selection. Enter 1, 2, 3, or 4: 0
Invalid selection. Enter 1, 2, 3, or 4: 2
You selected: Paper 
The computer selected: Paper 
Tie. No winner. 

************************************************************/
