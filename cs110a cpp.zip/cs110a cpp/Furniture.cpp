/*
* Class: CS 110A
* Description: This program allows users to input the amount of chairs sold and displays the total sales of each style and total sales of all chairs
* Due Date: February 17, 2016
* Name: Kelly Suen
* File Name: Furniture.cpp
* Lab #4
*/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int americanColonial, modern, frenchClassical;
	double americancolonial_totalSales, modern_totalSales, frenchclassical_totalSales, allchairs_totalSales;
	const double AMERICANCOLONIAL_PRICE = 85.00;
	const double MODERN_PRICE = 57.50;
	const double FRENCHCLASSICAL_PRICE = 127.75;

	cout << "Please input the number of American Colonial chairs sold " ;
	cin >> americanColonial;	//user inputs amount of american colonial chairs sold

	cout << "Please input the number of Modern chairs sold ";
	cin >> modern;		//user inputs amount of modern chairs sold

	cout << "Please input the number of French Classical chairs sold ";
	cin >> frenchClassical;		//user inputs amount of french classical chairs sold

	cout << setprecision(2) << fixed;	//shows two decimal points

	//calculates and displays total sales of American Colonials
	americancolonial_totalSales = AMERICANCOLONIAL_PRICE * americanColonial;
	cout << "\nThe total sales of American Colonial chairs $" << americancolonial_totalSales << endl;

	//calculates and displays total sales of Modern chairs
	modern_totalSales = MODERN_PRICE * modern;
	cout << "The total sales of Modern chairs $" << modern_totalSales << endl;

	//calculates and displays total sales of French Classical chairs
	frenchclassical_totalSales = FRENCHCLASSICAL_PRICE * frenchClassical;
	cout << "The total sales of French Classical chairs $" << frenchclassical_totalSales << endl; 

	//calculates and displays total sales of all chairs
	allchairs_totalSales = americancolonial_totalSales + modern_totalSales + frenchclassical_totalSales;
	cout << "The total sales of all chairs $" << allchairs_totalSales << endl;

	cout << "\nProgrammed by Kelly Suen" << endl;
}

//sample run
/* 
Please input the number of American Colonial chairs sold 15
Please input the number of Modern chairs sold 7
Please input the number of French Classical chairs sold 19

The total sales of American Colonial chairs $1275.00
The total sales of Modern chairs $402.50
The total sales of French Classical chairs $2427.25
The total sales of all chairs $4104.75

Programmed by Kelly Suen
*/
