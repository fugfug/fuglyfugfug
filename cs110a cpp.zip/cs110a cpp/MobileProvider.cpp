#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
        const double PACK_A = 39.99; //cost of package a per month
        const double PACK_B = 59.99; //cost of package b per month
        const double PACK_C = 69.99; // cost of package c per month including unlimited minutes
        const double PACKA_ADDITIONALMIN = .45; //price of additional a minute for package a 
        const double PACKB_ADDITIONALMIN = .40; // price of additional a minute for package b
        const double PACKA_MINUTES = 450; //minutes provided by package a
        const double PACKB_MINUTES = 900; // minutes provided by package b
        const int packageA = 1; //package a is choice 1
        const int packageB = 2; // package B is choice 2
        const int packageC = 3; //package C is choice 3

	int subscriptionPackage; //which subscription package was chosen
	double minutes;		//minutes used
	double amountDue;	//amount due for the month

	cout << "Select a subscription package: \n" 
	<< "1. Package A \n"
	<< "2. Package B \n"
	<< "3. Package C \n"
	<< "4. Quit" << endl ;
	cin >> subscriptionPackage ;

	//if the number entered by the user is between 1 and 3, program asks the user how many minutes were used
	//if the number entered is 4, program displays a quit message
	//if any other number is entered, it displays an invalid message
	if (subscriptionPackage >= 1 && subscriptionPackage <= 3) 
	{	cout << "How many minutes were used? " ;
		cin >> minutes ;
	}
	else if (subscriptionPackage == 4)
		cout << "Quit" << endl;
	else
		cout << "Invalid" << endl;

	
        cout << showpoint << fixed << setprecision(2);  
        switch (subscriptionPackage) {
                case 1:
                       	//if minutes used are greater than minutes provided by package A
                        if (minutes > PACKA_MINUTES) {
				//calculate amount due for package A, using minutes entered by user
                                amountDue = (minutes - PACKA_MINUTES) * PACKA_ADDITIONALMIN + PACK_A;
				//displays amount due
                                cout << "The total amount due is $" << amountDue << endl;
                        }                 
                        else
				//if minutes used by user were less than or equal to minutes provided by package A
                                cout << "The total amount due is $" << PACK_A << endl;
                break;
                case 2:
			//if minutes used are greater than minutes provided by package B
                        if (minutes > PACKB_MINUTES) {
                                //calculate amount due for package B, using minutes entered by user
                                amountDue = (minutes - PACKB_MINUTES) * PACKB_ADDITIONALMIN + PACK_B;
                                cout << "The total amount due is $" << amountDue << endl;
                        }                 
                        else
                                cout << "The total amount due is $" << PACK_B << endl;
                break;
                case 3:
                        cout << "The total amount due is $" << PACK_C << endl;
}

	return 0;

}


/* sample runs
Select a subscription package: 
1. Package A 
2. Package B 
3. Package C 
4. Quit
1
How many minutes were used? 2222
The total amount due is $837.39

Select a subscription package: 
1. Package A 
2. Package B 
3. Package C 
4. Quit
3
How many minutes were used? 888
The total amount due is $69.99


*/
