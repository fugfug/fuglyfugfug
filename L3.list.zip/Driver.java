import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ListReferencedBased list = new ListReferencedBased();

		menu();
		int choice = scan.nextInt(); //anything but 1 or 2 quits
		do {
			if (choice == 1) { // replace
				System.out.print("Enter a list of integers: ");

				try {
					int index = 0;
					Object item = scan.nextLine();
					while (!item.equals("-1")) { // stops adding items when -1
													// is entered
						item = scan.next();
						list.add(index, item);
						index++;
					}
				} catch (ListIndexOutOfBoundsException e) {
					System.out.println("Can't add.");//////////////////////////
				}

				System.out.print("Enter a value to be modified: ");
				Object replaceThis = scan.next();
				System.out.print("Enter replacement value: ");
				Object replacementValue = scan.next();

				System.out.print("Modified list: ");
				int itemsReplaced = list.replace(replaceThis, replacementValue);
				System.out.println("\nNumber of items replaced: " + itemsReplaced);
				System.out.println();
				menu();
				choice = scan.nextInt();
			}

			else if (choice == 2) { // compare lists
				System.out.print("Enter first list to be compared: ");

				try {
					int index = 0;
					Object item = scan.nextLine();
					while (!item.equals("-1")) { // stops adding items when -1
													// is entered
						item = scan.next();
						list.add(index, item);
						index++;
					}
				} catch (ListIndexOutOfBoundsException e) {
					System.out.println("Can't add.");
				}

				ListReferencedBased list2 = new ListReferencedBased();// create
																		// new
																		// list
				System.out.print("Enter second list to be compared: ");
				try {
					int index = 0;
					Object item = scan.nextLine();
					while (!item.equals("-1")) { // stops adding items when -1
													// is entered
						item = scan.next();
						list2.add(index, item);
						index++;
					}
					if (list2.equals(list)) {
						System.out.println("The two lists are equal.");
					} else {
						System.out.println("The two lists are not equal.");
					}
				} catch (ListIndexOutOfBoundsException e) {
					System.out.println("Can't add.");
				}
				System.out.println();
				menu();
				choice = scan.nextInt();
			}

		} while (choice != 3); 

	}

	public static void menu() {
		System.out.println("What do you want to do?");
		System.out.println(
				"1) Replace a value in a list of integers" + "\n2) Compare two lists of integers" + "\n3) Quit");
		System.out.print("Enter your choice: ");
	}

}
