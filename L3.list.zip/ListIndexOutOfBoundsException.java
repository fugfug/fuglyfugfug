
public class ListIndexOutOfBoundsException extends Exception {

	
	public ListIndexOutOfBoundsException(String s) {

		super(s);

	}
	
}
