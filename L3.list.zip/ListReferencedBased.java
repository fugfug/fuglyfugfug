import java.util.List;

public class ListReferencedBased implements ListInterface {
	// reference to linked list of items

	private Node head;
	private int numItems; // number of items in list

	// definitions of constructors and methods

	public ListReferencedBased() {
		numItems = 0;
		head = null;
	} // end default constructor

	public boolean isEmpty() {
		return numItems == 0;
	}

	public int size() {
		return numItems;
	} // end size
		// }

	private Node find(int index) {
		// �������������������
		// Locates a specified node in a linked list.
		// Precondition: index is the number of the desired
		// node. Assumes that 1 <= index <= numItems+1
		// Postcondition: Returns a reference to the desired
		// node.
		// �������������������

		Node curr = head;
		for (int skip = 0; skip < index; skip++) {
			curr = curr.next;
		} // end for
		return curr;
	} // end find
	
    public Object get(int index) throws ListIndexOutOfBoundsException {
//    private Object get(int index) throws ListIndexOutOfBoundsException {
        if (index >= 0 && index < numItems) {
            // get reference to node, then data in node
            Node curr = find(index);
            Object dataItem = curr.item;
            return dataItem;
        }
        else  {
             throw new ListIndexOutOfBoundsException("List index out of bounds on get");
        } // end if
   } // end get

	public void add(int index, Object item) throws ListIndexOutOfBoundsException {
		if (index >= 0 && index < numItems + 1) {
			if (index == 0) {
				// insert the new node containing item at
				// beginning of list
				Node newNode = new Node(item, head);
				head = newNode;
			} else {
				Node prev = find(index - 1);

				// insert the new node containing item after
				// the node that prev references
				Node newNode = new Node(item, prev.next);
				prev.next = newNode;
			} // end if

			numItems++;
		} else {
			throw new ListIndexOutOfBoundsException("List index out of bounds on add");
		} // end if
	} // end add

	public void remove(int index) throws ListIndexOutOfBoundsException {
		if (index >= 0 && index < numItems) {
			if (index == 0) {
				// delete the first node from the list
				head = head.next;
			} else {
				Node prev = find(index - 1);
				// delete the node after the node that prev
				// references, save reference to node
				Node curr = prev.next;
				prev.next = curr.next;
			} // end if

			numItems--;
		} else {
			throw new ListIndexOutOfBoundsException("List index out of bounds on remove");
		} // end if
	} // end remove

	public void removeAll() {
		// setting head to null causes list to be
		// unreachable and thus marked for garbage collection
		head = null;
		numItems = 0;
	} // end removeAll

	// precondition: the inputs oldValue and newValue are objects
	// postcondition: returns number of changes made
	public int replace(Object oldValue, Object newValue) {
		// replaces each occurrence of oldValue in the list with newValue
		// returns number of items replaced
		int numReplaced = 0;
		for(Node curr = head; curr.next != null; curr = curr.next){
			if(curr.item.equals(oldValue)) {
				curr.item = newValue;
				numReplaced++;
			}
		}
		return numReplaced; 
	}
	
	// precondition: aList is a List
	// postcondition: returns true if the lists are equal
	public boolean equals(List aList){
	// returns true if aList has the same values in the same order as the
	// current list object; else returns false
		int[] first = new int[numItems];
		int i = 0;
		for(Node curr = head; curr.next!=null; curr = curr.next){
			first[i] = (int)curr.item;
			i++;
		}
	
        if(numItems!=aList.size())
            return false;
        for (Node curr1 = head; curr1.next != null; curr1 = curr1.next) {
            if (!curr1.item.equals(first[i]))
            	return false;
        }
        return true;
    }
	
	// precondition: none
	// postcondition: displays list
	// traverses list to display list
	public void display() {
		for(Node curr = head; curr.next != null; curr = curr.next) {
			System.out.print(curr.item + " ");
		}
	}
	
}
