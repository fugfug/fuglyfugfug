/*
 * 
 * Kelly Suen
 * Lab 1
 * Eclipse
 * Windows 10
 * 
 */

public class Towers {

	public static void main(String[] args) {

		solveTowers(3, 'A', 'B', 'C');

	}

	public static void solveTowers(int count, char source, char destination, char spare) {
		// solves Towers of Hanoi problem
		// count is the amount of rings
		if (count == 1) {
			System.out.println("Move top disk from pole " + source + " to pole " + destination);
		} else {
			solveTowers(count - 1, source, spare, destination);
			solveTowers(1, source, destination, spare);
			solveTowers(count - 1, spare, destination, source);
		}
	}
}

