/*
 * 
 * Kelly Suen
 * Lab 1
 * Eclipse
 * Windows 10
 */
public class TripleCallCounter {

	public static void main(String[] args) {
		System.out.println(solveTripleCounter(5));

	}
	
	public static int solveTripleCounter(int n) {
		// 2^n - 1 = T(n)
		// takes n and returns the value of T(n) = T(n - 1) + T(1) + T(n - 1) using recursion
		// n is an integer that is greater than or equal to 0
		// returns the value of T(n)
		if (n == 0) //base case
			return 0;
		else if (n == 1) //base case
			return 1;
		else 
			return solveTripleCounter(n - 1) + solveTripleCounter(1) + solveTripleCounter(n - 1);
		

	}

}
