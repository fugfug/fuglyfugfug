
/*
 * 
 * Kelly Suen
 * Lab 1
 * Eclipse
 * Windows 10
 */

public class Formula3 {

	public static void main(String[] args) {

		System.out.println("non recursive: " + factorial(3));
		System.out.println("recursive: " + power3(3));

		System.out.println("non recursive: " + factorial(5));
		System.out.println("recursive: " + power3(5));

	}

	public static int power3(int n) {
		// calculates x^n by using the recursive formula: x^n = x * x^(n-1)
		// n is an integer that must be greater than or equal to 0
		// returns the value of x^n
		if (n > 0)
			return n * power3(n - 1);
		else // n<=0
			return 1;

	}
	
	public static int factorial(int n) {
		// Calculate values for x^n without using recursion
		// n is an integer that must be greater than or equal to 0
		// returns the value of x^n
		int x = 1; //
		while (n > 0) {
			x = x * n;
			n--;
		}
		return x;
	}
}
